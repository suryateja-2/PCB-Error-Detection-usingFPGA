`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 21.03.2026 14:20:38
// Design Name: 
// Module Name: pcb_inspection_top
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////



module pcb_inspection_top (
    input  wire        clk_100mhz,
    output wire [3:0]  red, green, blue,
    output wire        hsync, vsync
);

    reg [1:0] clk_div = 0;
    always @(posedge clk_100mhz) clk_div <= clk_div + 1;
    wire clk_25 = clk_div[1];

    wire [9:0] pixel_x, pixel_y;
    wire video_on;

    vga_controller vga (
        .clk_25mhz(clk_25),
        .hsync(hsync),
        .vsync(vsync),
        .pixel_x(pixel_x),
        .pixel_y(pixel_y),
        .video_on(video_on)
    );

   wire valid_img = (pixel_x < 512) && (pixel_y < 512);

wire [18:0] addr = (video_on && valid_img) ? 
    ((pixel_y << 9) + pixel_x) : 
    19'd0;


    wire [7:0] test_px, template_px;

    blk_mem_gen_0 test_rom (
        .clka(clk_25),
        .ena(1'b1),
        .addra(addr),
        .douta(test_px)
    );

    blk_mem_gen_1 template_rom (
        .clka(clk_25),
        .ena(1'b1),
        .addra(addr),
        .douta(template_px)
    );

    wire pos_defect, neg_defect;

    defect_detector detect (
        .test_pixel(test_px),
        .template_pixel(template_px),
        .pos_defect(pos_defect),
        .neg_defect(neg_defect)
    );

wire [11:0] base_gray = {test_px[7:4], test_px[7:4], test_px[7:4]};

wire [11:0] rgb = video_on ? 
    (pos_defect ? 12'hF00 :   
     neg_defect ? 12'h00F :   
     base_gray) :             
    12'h000;

    assign red   = rgb[11:8];
    assign green = rgb[7:4];
    assign blue  = rgb[3:0];

endmodule