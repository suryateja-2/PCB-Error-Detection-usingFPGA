`timescale 1ns/1ps

module vga_controller (
    input  wire        clk_25mhz,
    output reg         hsync,
    output reg         vsync,
    output wire [9:0]  pixel_x,
    output wire [9:0]  pixel_y,
    output wire        video_on
);
    reg [9:0] h_count = 0;
    reg [9:0] v_count = 0;
    
    assign pixel_x = h_count;
    assign pixel_y = v_count;
    assign video_on = (h_count < 640) && (v_count < 480);
    
    always @(posedge clk_25mhz) begin

        if (h_count == 799) begin
            h_count <= 0;
            v_count <= (v_count == 524) ? 0 : v_count + 1;
        end else begin
            h_count <= h_count + 1;
        end

        hsync <= ~(h_count >= 656 && h_count < 752);
        vsync <= ~(v_count >= 490 && v_count < 492);
    end
endmodule