`timescale 1ns / 1ps
module defect_detector (
    input  wire [7:0] test_pixel,
    input  wire [7:0] template_pixel,
    output reg        pos_defect,
    output reg        neg_defect
);
    always @(*) begin
        pos_defect    = (test_pixel > template_pixel + 8'd10);
        neg_defect    = (test_pixel + 8'd10 < template_pixel);
    end
endmodule 